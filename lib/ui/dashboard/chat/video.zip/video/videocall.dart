// ignore_for_file: non_constant_identifier_names, prefer_typing_uninitialized_variables, prefer_final_fields, sort_child_properties_last, unused_field, unnecessary_null_comparison, unused_element

import 'dart:developer';
import 'package:agora_rtc_engine/agora_rtc_engine.dart';
import 'package:agora_uikit/agora_uikit.dart';
import 'package:datingapp/component/alert_box.dart';
import 'package:datingapp/component/apptext.dart';
import 'package:datingapp/component/color_const.dart';
import 'package:datingapp/feature/dashboard/chat/model/sent_notification.dart';
import 'package:datingapp/service/auth_repository.dart';
import 'package:flutter/material.dart';
import 'package:native_device_orientation/native_device_orientation.dart';
import 'package:sizer/sizer.dart';
import 'package:velocity_x/velocity_x.dart';
import '../../../../service/main_repository.dart';

const appId = "2dcd37721d654e61a6e50a89695b2a79";
String channelName = "";
String userToken = "";

class VideoCall extends StatefulWidget {
  final String userId;
  const VideoCall({super.key, required this.userId});
  //  required this.appName, required this.toekn

  @override
  State<VideoCall> createState() => _VideoCallState();
}

class _VideoCallState extends State<VideoCall> {
  RtcEngineEventHandler? _engineEventHandler;

  String uid = "";
  int? _remoteUid;
  bool _localUserJoined = false;
  void _updateOffset(Offset offset) {
    setState(() {
      _offset = Offset(
        offset.dx.clamp(30, 70.w),
        offset.dy.clamp(30, 80.h),
      );
    });
  }

  late RtcEngine _engine;
  Future<void> initAgora(String tokens, String Channelname) async {
    // retrieve permissions

    await [Permission.microphone, Permission.camera].request();

    //create the engine
    _engine = createAgoraRtcEngine();
    await _engine.initialize(const RtcEngineContext(
      appId: appId,
      channelProfile: ChannelProfileType.channelProfileCommunication,
    ));
// _engine.onJ

    _engine.registerEventHandler(
      RtcEngineEventHandler(
        onJoinChannelSuccess: (RtcConnection connection, int elapsed) {
          debugPrint("==================> local ${connection.localUid} joined");

          setState(() {
            // _localUserJoined = true;
            uid = connection.localUid.toString();
          });
        },
        onUserJoined: (RtcConnection connection, int remoteUid, int elapsed) {
          log("==================> remote $remoteUid joined");
          log("message");

          // showDialog(
          //     context: context,
          //     builder: (_) => AlertBox(title: "remote user $remoteUid joined"));
          setState(() {
            _remoteUid = remoteUid;
            // 1165443601
          });
          log("==================> remote $_remoteUid set");
        },
        onRejoinChannelSuccess: (connection, elapsed) {
          log("message : - onJoinChannel ${connection.localUid}");
        },
        onUserOffline: (RtcConnection connection, int remoteUid,
            UserOfflineReasonType reason) {
          _leaveChannel();
          Navigator.of(context).pop();
          showDialog(
              context: context,
              builder: (_) => const AlertBox(title: "Call Ended"));
          log("==================> exite $remoteUid left channel");
          setState(() {
            _remoteUid = null;
          });
        },
        onLeaveChannel: (connection, stats) {
          log("==================> ${stats.duration} ${connection.channelId} ${connection.localUid}");
        },
        onTokenPrivilegeWillExpire: (RtcConnection connection, String token) {
          log('==================> [onTokenPrivilegeWillExpire] connection: ${connection.toJson()}, token: $token');
        },
      ),
    );

    await _engine.setClientRole(role: ClientRoleType.clientRoleBroadcaster);
    await _engine.enableVideo();
    await _engine.enableAudio();
    await _engine.startPreview();

    await _engine.joinChannel(
      token: tokens,
      channelId: Channelname,
      uid: 0,
      options: const ChannelMediaOptions(),
    );
  }

  void _switchCamera() {
    _engine.switchCamera();
  }

  // Function to leave the channel
  void _leaveChannel() {
    if (_engine != null) {
      _engine.leaveChannel();

      _engine.release();
      // await _engine.destroyCustomEncodedVideoTrack(videoTrackId);
    }
  }

  Offset _offset = const Offset(0.0, 0.0);
  bool loading = false;
  AgoraVideoCall _repository = AgoraVideoCall();
  DatingAppAuthRepo _authRepo = DatingAppAuthRepo();
  late var client;

  getToken() async {
    setState(() {
      loading = false;
    });
    // try {
    final deviceResponse = await _repository.getToken();
    channelName = deviceResponse.result?.channelName ?? "";
    userToken = deviceResponse.result?.token ?? "";
    log(' ==================>this is the server token $userToken $channelName');
    initAgora(userToken, channelName);
    /* catch (e) {
      normalerrorstate(context, e.toString());
    } */
    setState(() {
      loading = true;
    });

    // await client.initialize();

    sentNotification response = await _authRepo.sentNoti(
        widget.userId, channelName, userToken, "video");
    log('this is api result ${response.status.toString()}');
  }

  // int uid = 0;
  late RtcEngine agoraEngine;

  final GlobalKey<ScaffoldMessengerState> scaffoldMessengerKey =
      GlobalKey<ScaffoldMessengerState>();

  showMessage(String message) {
    scaffoldMessengerKey.currentState?.showSnackBar(SnackBar(
      content: Text(message),
    ));
  }

  void _toggleMute() {
    bool muted = !_localUserJoined;
    log("$muted   ++++++++++++++++++++++>");
    _engine.muteLocalAudioStream(muted);
    // if (muted) {
    //   _engine.muteLocalAudioStream(false);
    // } else {
    //   _engine.muteLocalAudioStream(tr);
    // }
    setState(() {
      _localUserJoined = muted;
    });
  }

  bool disableviceo = false;
  void closecamera() {
    bool muted = !disableviceo;
    _engine.muteLocalVideoStream(muted);
    setState(() {
      disableviceo = muted;
    });
  }

  @override
  void initState() {
    getToken();
    super.initState();
  }

  @override
  void deactivate() {
    // Navigator.of(context).pop();
    _leaveChannel();
    super.deactivate();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(body: NativeDeviceOrientationReader(builder: (context) {
      return Container(
        // duration: Duration(milliseconds: 100),
        decoration: BoxDecoration(
            image:
                DecorationImage(image: Image.asset("assets/splash.png").image)),
        child: SafeArea(
            child: loading
                ? Stack(
                    children: [
                      _remoteUid != null
                          ? _remoteVideo()
                          : AgoraVideoView(
                              onAgoraVideoViewCreated: (i) {
                                log(" ======+++++++++++++++++==========++++++++++======++++++++++=+>");
                              },
                              controller: VideoViewController(
                                rtcEngine: _engine,
                                canvas: const VideoCanvas(
                                  uid: 0,
                                ),
                              ),
                            ),
                      Positioned(
                        left: _offset.dx,
                        top: _offset.dy,
                        child: Draggable(
                          child: _remoteUid != null
                              ? Container(
                                  height: 20.h,
                                  width: 30.w,
                                  clipBehavior: Clip.antiAlias,
                                  decoration: BoxDecoration(
                                      // color: bgClr,
                                      borderRadius: BorderRadius.circular(14),
                                      border: Border.all(color: blackColor)),
                                  child: AgoraVideoView(
                                    onAgoraVideoViewCreated: (i) {
                                      log(" ======+++++++++++++++++==========++++++++++======++++++++++=+>");
                                    },
                                    controller: VideoViewController(
                                      rtcEngine: _engine,
                                      canvas: const VideoCanvas(
                                        uid: 0,
                                      ),
                                    ),
                                  ),
                                )
                              : _remoteVideo(),
                          feedback: Container(),
                          onDraggableCanceled: (velocity, offset) {
                            _updateOffset(offset);
                          },
                        ),
                      ),
                      Positioned(
                        bottom: 0, // Adjust the position as needed
                        left: 0,
                        right: 0,
                        child: Center(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Container(
                                      decoration: BoxDecoration(
                                          shape: BoxShape.circle, color: bgClr),
                                      child: Icon(_localUserJoined
                                          ? Icons.mic_off_outlined
                                          : Icons.mic),
                                      width: 60,
                                      height: 60)
                                  .onTap(() {
                                _toggleMute();
                              }),
                              GestureDetector(
                                  onTap: () {
                                    Navigator.of(context).pop();
                                    _leaveChannel();
                                  },
                                  child: Image.asset("assets/callend.png",
                                      width: 60, height: 60)),
                              Container(
                                      decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          color: disableviceo == false
                                              ? whitecolor
                                              : bgClr),
                                      child: const Icon(Icons.videocam_rounded),
                                      width: 60,
                                      height: 60)
                                  .onTap(() {
                                closecamera();
                              }),
                            ],
                          ).pOnly(left: 4.w, right: 4.w, bottom: 2.h),
                        ),
                      ),
                    ],
                  )
                : const Center(
                    child: CircularProgressIndicator(),
                  )),
      );
    }));
  }

  @override
  void dispose() {
    log("dispose ================++++++++>");
    _leaveChannel();
    super.dispose();
  }

  Widget _remoteVideo() {
    if (_remoteUid != null) {
      return AgoraVideoView(
        controller: VideoViewController.remote(
          rtcEngine: _engine,
          canvas: VideoCanvas(uid: _remoteUid),
          connection: RtcConnection(channelId: channelName),
        ),
      );
    } else {
      return AppText(
          fontWeight: FontWeight.w400, size: 20.sp, text: "Please Wait ....");
    }
  }
}
