import 'package:datingapp/feature/dashboard/chat/model/get_toekn_model.dart';
import 'package:flutter/cupertino.dart';

@immutable
abstract class VideoCallState {}

class VideoCallInitialState extends VideoCallState {}

class VideoCallSuccessState extends VideoCallState {
  final GetToken response;
  VideoCallSuccessState(this.response);
}

class VideoCallLoadingState extends VideoCallState {}

class VideoCallErrorState extends VideoCallState {
  final String message;
  VideoCallErrorState(this.message);
}
