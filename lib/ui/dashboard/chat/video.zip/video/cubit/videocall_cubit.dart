import 'package:datingapp/feature/dashboard/chat/model/get_toekn_model.dart';
import 'package:datingapp/feature/dashboard/chat/video/cubit/videocall_state.dart';
import 'package:datingapp/service/main_repository.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class VideoCallCubit extends Cubit<VideoCallState> {
  final DatingAppMainRepo _repository;

  VideoCallCubit(this._repository) : super(VideoCallInitialState());

  Future<void> videoCall() async {
    try {
      emit(VideoCallLoadingState());

      GetToken deviceResponse = await _repository.getToken();

      emit(VideoCallSuccessState(deviceResponse));

      // log(deleteResponse.toString());
    } catch (e) {
      emit(VideoCallErrorState(e.toString()));
    }
  }
}
