// ignore_for_file: prefer_typing_uninitialized_variables, sort_child_properties_last, unnecessary_null_comparison

import 'dart:developer';

import 'package:agora_rtc_engine/agora_rtc_engine.dart';
import 'package:agora_uikit/agora_uikit.dart';
import 'package:datingapp/component/alert_box.dart';
import 'package:datingapp/component/apptext.dart';
import 'package:datingapp/component/color_const.dart';
import 'package:flutter/material.dart';
import 'package:native_device_orientation/native_device_orientation.dart';
import 'package:sizer/sizer.dart';
import 'package:velocity_x/velocity_x.dart';

const appId = "f67bf31654fd4b968395839f27661ab2";
String token = "";

//  channel = "hello";
class ReceivedVideoCall extends StatefulWidget {
  final String channelName, token;
  const ReceivedVideoCall(
      {super.key, required this.channelName, required this.token});

  @override
  State<ReceivedVideoCall> createState() => _ReceivedVideoCallState();
}

class _ReceivedVideoCallState extends State<ReceivedVideoCall> {
  int? _remoteUid;
  String uid = "";
  void _updateOffset(Offset offset) {
    setState(() {
      _offset = Offset(
        offset.dx.clamp(30, 70.w),
        offset.dy.clamp(30, 80.h),
      );
    });
  }

  bool _localUserJoined = false;
  late RtcEngine _engine;
  Offset _offset = const Offset(0.0, 0.0);
  Future<void> initAgora(String tokens, String Channelname) async {
    // retrieve permissions

    await [Permission.microphone, Permission.camera].request();

    //create the engine
    _engine = createAgoraRtcEngine();
    await _engine.initialize(const RtcEngineContext(
      appId: appId,
      channelProfile: ChannelProfileType.channelProfileCommunication,
    ));
// _engine.onJ

    _engine.registerEventHandler(
      RtcEngineEventHandler(
        onJoinChannelSuccess: (RtcConnection connection, int elapsed) {
          debugPrint("==================> local ${connection.localUid} joined");

          setState(() {
            // _localUserJoined = true;
            uid = connection.localUid.toString();
          });
        },
        onUserJoined: (RtcConnection connection, int remoteUid, int elapsed) {
          log("==================> remote $remoteUid joined");
          log("message");

          // showDialog(
          //     context: context,
          //     builder: (_) => AlertBox(title: "remote user $remoteUid joined"));
          setState(() {
            _remoteUid = remoteUid;
            // 1165443601
          });
          log("==================> remote $_remoteUid set");
        },
        onRejoinChannelSuccess: (connection, elapsed) {
          log("message : - onJoinChannel ${connection.localUid}");
        },
        onUserOffline: (RtcConnection connection, int remoteUid,
            UserOfflineReasonType reason) {
          _leaveChannel();
          Navigator.of(context).pop();
          showDialog(
              context: context,
              builder: (_) => const AlertBox(title: "Call Ended"));
          log("==================> exite $remoteUid left channel");
          setState(() {
            _remoteUid = null;
          });
        },
        onLeaveChannel: (connection, stats) {
          log("==================> ${stats.duration} ${connection.channelId} ${connection.localUid}");
        },
        onTokenPrivilegeWillExpire: (RtcConnection connection, String token) {
          debugPrint(
              '[onTokenPrivilegeWillExpire] connection: ${connection.toJson()}, token: $token');
        },
      ),
    );

    await _engine.setClientRole(role: ClientRoleType.clientRoleBroadcaster);
    await _engine.enableVideo();
    await _engine.enableAudio();
    await _engine.startPreview();

    await _engine.joinChannel(
      token: tokens,
      channelId: Channelname,
      uid: 0,
      options: const ChannelMediaOptions(),
    );
  }

  /*  void _switchCamera() {
    _engine.switchCamera();
  }
 */
  // Function to leave the channel
  void _leaveChannel() {
    if (_engine != null) {
      _engine.leaveChannel();
      _engine.release();
    }
  }

  bool loading = false;

  late var client;

  getToken() async {
    setState(() {
      loading = false;
    });
    initAgora(widget.token, widget.channelName);
    setState(() {
      loading = true;
    });
  }

  late RtcEngine agoraEngine;

  final GlobalKey<ScaffoldMessengerState> scaffoldMessengerKey =
      GlobalKey<ScaffoldMessengerState>();

  showMessage(String message) {
    scaffoldMessengerKey.currentState?.showSnackBar(SnackBar(
      content: Text(message),
    ));
  }

  void _toggleMute() {
    bool muted = !_localUserJoined;
    _engine.muteLocalAudioStream(muted);

    setState(() {
      _localUserJoined = muted;
    });
  }

  bool disableviceo = false;
  void closecamera() {
    bool muted = !disableviceo;
    _engine.muteLocalVideoStream(muted);
    setState(() {
      disableviceo = muted;
    });
  }

  @override
  void initState() {
    getToken();
    super.initState();
  }

  @override
  void deactivate() {
    _leaveChannel();
    super.deactivate();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(body: NativeDeviceOrientationReader(builder: (context) {
      return Container(
        // duration: const Duration(milliseconds: 100),
        decoration: BoxDecoration(
            /* image: DecorationImage(
                    image: Image.asset("assets/splash.png").image) */
            ),
        child: SafeArea(
            child: loading
                ? Stack(
                    children: [
                      _remoteUid != null
                          ? _remoteVideo()
                          : AgoraVideoView(
                              onAgoraVideoViewCreated: (i) {
                                log(" ======+++++++++++++++++==========++++++++++======++++++++++=+>");
                              },
                              controller: VideoViewController(
                                rtcEngine: _engine,
                                canvas: const VideoCanvas(
                                  uid: 0,
                                ),
                              ),
                            ),
                      Positioned(
                        left: _offset.dx,
                        top: _offset.dy,
                        child: Draggable(
                          child: _remoteUid != null
                              ? Container(
                                  height: 20.h,
                                  width: 30.w,
                                  clipBehavior: Clip.antiAlias,
                                  decoration: BoxDecoration(
                                      // color: bgClr,

                                      borderRadius: BorderRadius.circular(14),
                                      image: DecorationImage(
                                          image:
                                              Image.asset("assets/splash.png")
                                                  .image),
                                      border: Border.all(color: blackColor)),
                                  child: AgoraVideoView(
                                    onAgoraVideoViewCreated: (i) {
                                      log(" ======+++++++++++++++++==========++++++++++======++++++++++=+>");
                                    },
                                    controller: VideoViewController(
                                      rtcEngine: _engine,
                                      canvas: const VideoCanvas(
                                        uid: 0,
                                      ),
                                    ),
                                  ),
                                )
                              : _remoteVideo(),
                          feedback: Container(),
                          onDraggableCanceled: (velocity, offset) {
                            _updateOffset(offset);
                          },
                        ),
                      ),
                      Positioned(
                        bottom: 0, // Adjust the position as needed
                        left: 0,
                        right: 0,
                        child: Center(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Container(
                                      decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          color: _localUserJoined == false
                                              ? whitecolor
                                              : bgClr),
                                      child: const Icon(Icons.mic_off_outlined),
                                      width: 60,
                                      height: 60)
                                  .onTap(() {
                                _toggleMute();
                              }),
                              GestureDetector(
                                  onTap: () {
                                    Navigator.of(context).pop();
                                    _leaveChannel();
                                  },
                                  child: Image.asset("assets/callend.png",
                                      width: 60, height: 60)),
                              Container(
                                      decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          color: disableviceo == false
                                              ? whitecolor
                                              : bgClr),
                                      child: const Icon(Icons.videocam_rounded),
                                      width: 60,
                                      height: 60)
                                  .onTap(() {
                                closecamera();
                              }),
                            ],
                          ).pOnly(left: 4.w, right: 4.w, bottom: 2.h),
                        ),
                      ),
                    ],
                  )
                : const Center(
                    child: CircularProgressIndicator(),
                  )),
      );
    }));
  }

  @override
  void dispose() {
    Navigator.of(context).pop();
    _leaveChannel();
    // controller.dispose();
    super.dispose();
  }

  Widget _remoteVideo() {
    if (_remoteUid != null) {
      return Container(
        // height: 50.h,
        // width: 50.w,
        // color: bgClr,
        decoration: BoxDecoration(
          image: DecorationImage(image: Image.asset("assets/splash.png").image),
        ),
        child: AgoraVideoView(
          controller: VideoViewController.remote(
            rtcEngine: _engine,
            canvas: VideoCanvas(uid: _remoteUid),
            connection: RtcConnection(channelId: widget.channelName),
          ),
        ),
      );
    } else {
      return AppText(
              fontWeight: FontWeight.w400,
              size: 20.sp,
              text:
                  "Please Wait ....") /* Text(
        'Please Wait ....',style: TextStyle(),
        textAlign: TextAlign.center,
      ) */
          ;
    }
  }
}
