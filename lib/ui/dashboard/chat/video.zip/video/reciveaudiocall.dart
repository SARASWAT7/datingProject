// ignore_for_file: prefer_typing_uninitialized_variables, sort_child_properties_last, depend_on_referenced_packages, unused_field, unnecessary_null_comparison

import 'dart:developer';

import 'package:agora_rtc_engine/agora_rtc_engine.dart';
import 'package:agora_uikit/agora_uikit.dart';
import 'package:datingapp/component/alert_box.dart';
import 'package:datingapp/component/color_const.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:velocity_x/velocity_x.dart';

const appId = "2dcd37721d654e61a6e50a89695b2a79";

class ReceivedAudioCall extends StatefulWidget {
  final String channelName, token;
  const ReceivedAudioCall(
      {super.key, required this.channelName, required this.token});

  @override
  State<ReceivedAudioCall> createState() => _ReceivedAudioCallState();
}

class _ReceivedAudioCallState extends State<ReceivedAudioCall> {
  String uid = "";
  int? _remoteUid;
  int? _localUid;
  bool _localUserJoined = true;
  late RtcEngine _engine;
  Future<void> initAgora(String tokens, String Channelname) async {
    // retrieve permissions

    await [Permission.microphone].request();

    //create the engine
    _engine = createAgoraRtcEngine();
    await _engine.initialize(const RtcEngineContext(
      appId: appId,
      channelProfile: ChannelProfileType.channelProfileCommunication,
    ));
// _engine.onJ
    _engine.registerEventHandler(
      RtcEngineEventHandler(
        onJoinChannelSuccess: (RtcConnection connection, int elapsed) {
          log("==================> local ${connection.localUid} joined");

          setState(() {
            // _localUserJoined = true;
            // uid = connection.localUid.toString();
          });
        },
        onUserJoined: (RtcConnection connection, int remoteUid, int elapsed) {
          log("==================> remote $remoteUid joined");
          log("message");

          setState(() {
            _remoteUid = remoteUid;
            // 1165443601
          });
          log("==================> remote $_remoteUid set");
        },
        onRejoinChannelSuccess: (connection, elapsed) {
          log("message : - onJoinChannel ${connection.localUid}");
        },
        onUserOffline: (RtcConnection connection, int remoteUid,
            UserOfflineReasonType reason) {
          _leaveChannel();
          Navigator.of(context).pop();
          showDialog(
              context: context,
              builder: (_) => const AlertBox(title: "Call Ended"));
          log("==================> exite $remoteUid left channel");
          setState(() {
            _remoteUid = null;
          });
        },
        onLeaveChannel: (connection, stats) {
          log("==================> ${stats.duration} ${connection.channelId} ${connection.localUid}");
        },
        onTokenPrivilegeWillExpire: (RtcConnection connection, String token) {
          debugPrint(
              '[onTokenPrivilegeWillExpire] connection: ${connection.toJson()}, token: $token');
        },
      ),
    );

    await _engine.setClientRole(role: ClientRoleType.clientRoleBroadcaster);
    await _engine.disableVideo();
    await _engine.enableAudio();
    await _engine.startPreview();

    await _engine.joinChannel(
      token: tokens,
      channelId: Channelname,
      uid: 0,
      options: const ChannelMediaOptions(),
    );
  }

  bool loading = false;
  late var client;
  getToken() async {
    setState(() {
      loading = false;
    });
    log(' ==================>this is the server token ${widget.token} ${widget.channelName}');
    // log('this is the server channnel name ${deviceResponse.result!.channelName.toString()}');
    initAgora(widget.token, widget.channelName);
    setState(() {
      loading = true;
    });
  }

  // late RtcEngine agoraEngine;

  final GlobalKey<ScaffoldMessengerState> scaffoldMessengerKey =
      GlobalKey<ScaffoldMessengerState>();

  showMessage(String message) {
    scaffoldMessengerKey.currentState?.showSnackBar(SnackBar(
      content: Text(message),
    ));
  }

  void _toggleMute() {
    bool muted = !_localUserJoined;
    log("$muted ================++++++++>");
    _engine.muteLocalAudioStream(muted);
    setState(() {
      _localUserJoined = muted;
    });
  }

  void _leaveChannel() async {
    if (_engine != null) {
      _engine.leaveChannel();
      _engine.release();
    }
  }

  @override
  void initState() {
    // print(widget.userId);
    super.initState();
    getToken();
  }

  @override
  void deactivate() {
    // Navigator.of(context).pop();
    _leaveChannel();
    super.deactivate();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Container(
      // duration: Duration(milliseconds: 100),
      decoration: BoxDecoration(
          image:
              DecorationImage(image: Image.asset("assets/splash.png").image)),
      child: SafeArea(
          child: loading
              ? Stack(
                  children: [
                    AgoraVideoView(
                      controller: VideoViewController(
                        rtcEngine: _engine,
                        canvas: VideoCanvas(
                          uid: 0,
                        ),
                      ),
                    ),
                    Positioned(
                      bottom: 0, // Adjust the position as needed
                      left: 0,
                      right: 0,
                      child: Center(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(
                                    decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: /* _localUserJoined == false
                                            ? blackColor
                                            : */
                                            bgClr),
                                    child: Icon(_localUserJoined == false
                                        ? Icons.mic_off_outlined
                                        : Icons.mic),
                                    width: 60,
                                    height: 60)
                                .onTap(() {
                              _toggleMute();
                            }),
                            GestureDetector(
                                onTap: () {
                                  Navigator.of(context).pop();
                                  _leaveChannel();
                                },
                                child: Image.asset("assets/callend.png",
                                    width: 60, height: 60)),
                          ],
                        ).pOnly(left: 4.w, right: 4.w, bottom: 2.h),
                      ),
                    ),
                  ],
                )
              : const Center(
                  child: CircularProgressIndicator(),
                )),
    ));
  }
}
